import InfoBox from './info-box.component'
module.exports = InfoBox
