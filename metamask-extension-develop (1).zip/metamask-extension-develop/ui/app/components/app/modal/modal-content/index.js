export { default } from './modal-content.component'
