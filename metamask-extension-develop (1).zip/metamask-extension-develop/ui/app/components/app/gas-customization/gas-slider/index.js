export { default } from './gas-slider.component'
