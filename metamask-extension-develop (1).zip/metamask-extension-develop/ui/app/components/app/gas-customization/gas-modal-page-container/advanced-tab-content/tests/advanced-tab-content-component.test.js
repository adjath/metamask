import React from 'react'
import assert from 'assert'
import shallow from '../../../../../../../lib/shallow-with-context'
import sinon from 'sinon'
import AdvancedTabContent from '../advanced-tab-content.component.js'

import GasPriceChart from '../../../gas-price-chart'
import Loading from '../../../../../ui/loading-screen'

const propsMethodSpies = {
  updateCustomGasPrice: sinon.spy(),
  updateCustomGasLimit: sinon.spy(),
}

sinon.spy(AdvancedTabContent.prototype, 'renderDataSummary')

describe('AdvancedTabContent Component', function () {
  let wrapper

  beforeEach(() => {
    wrapper = shallow(<AdvancedTabContent
      updateCustomGasPrice={propsMethodSpies.updateCustomGasPrice}
      updateCustomGasLimit={propsMethodSpies.updateCustomGasLimit}
      customModalGasPriceInHex="11"
      customModalGasLimitInHex="23456"
      timeRemaining="21500"
      transactionFee="$0.25"
      insufficientBalance={false}
      customPriceIsSafe
      isSpeedUp={false}
      isEthereumNetwork
    />)
  })

  afterEach(() => {
    propsMethodSpies.updateCustomGasPrice.resetHistory()
    propsMethodSpies.updateCustomGasLimit.resetHistory()
    AdvancedTabContent.prototype.renderDataSummary.resetHistory()
  })

  describe('render()', () => {
    it('should render the advanced-tab root node', () => {
      assert(wrapper.hasClass('advanced-tab'))
    })

    it('should render the expected four children of the advanced-tab div', () => {
      const advancedTabChildren = wrapper.children()
      assert.equal(advancedTabChildren.length, 2)

      assert(advancedTabChildren.at(0).hasClass('advanced-tab__transaction-data-summary'))
      assert(advancedTabChildren.at(1).hasClass('advanced-tab__fee-chart'))

      const feeChartDiv = advancedTabChildren.at(1)

      assert(feeChartDiv.childAt(1).childAt(0).hasClass('advanced-tab__fee-chart__title'))
      assert(feeChartDiv.childAt(1).childAt(1).is(GasPriceChart))
      assert(feeChartDiv.childAt(1).childAt(2).hasClass('advanced-tab__fee-chart__speed-buttons'))
    })

    it('should render a loading component instead of the chart if gasEstimatesLoading is true', () => {
      wrapper.setProps({ gasEstimatesLoading: true })
      const advancedTabChildren = wrapper.children()
      assert.equal(advancedTabChildren.length, 2)

      assert(advancedTabChildren.at(0).hasClass('advanced-tab__transaction-data-summary'))
      assert(advancedTabChildren.at(1).hasClass('advanced-tab__fee-chart'))

      const feeChartDiv = advancedTabChildren.at(1)

      assert(feeChartDiv.childAt(1).childAt(0).hasClass('advanced-tab__fee-chart__title'))
      assert(feeChartDiv.childAt(1).childAt(1).is(Loading))
      assert(feeChartDiv.childAt(1).childAt(2).hasClass('advanced-tab__fee-chart__speed-buttons'))
    })

    it('should call renderDataSummary with the expected params', () => {
      const renderDataSummaryArgs = AdvancedTabContent.prototype.renderDataSummary.getCall(0).args
      assert.deepEqual(renderDataSummaryArgs, ['$0.25', 21500])
    })
  })

  describe('renderDataSummary()', () => {
    let dataSummary

    beforeEach(() => {
      dataSummary = shallow(wrapper.instance().renderDataSummary('mockTotalFee', 'mockMsRemaining'))
    })

    it('should render the transaction-data-summary root node', () => {
      assert(dataSummary.hasClass('advanced-tab__transaction-data-summary'))
    })

    it('should render titles of the data', () => {
      const titlesNode = dataSummary.children().at(0)
      assert(titlesNode.hasClass('advanced-tab__transaction-data-summary__titles'))
      assert.equal(titlesNode.children().at(0).text(), 'newTransactionFee')
      assert.equal(titlesNode.children().at(1).text(), '~transactionTime')
    })

    it('should render the data', () => {
      const dataNode = dataSummary.children().at(1)
      assert(dataNode.hasClass('advanced-tab__transaction-data-summary__container'))
      assert.equal(dataNode.children().at(0).text(), 'mockTotalFee')
      assert(dataNode.children().at(1).hasClass('advanced-tab__transaction-data-summary__time-remaining'))
      assert.equal(dataNode.children().at(1).text(), 'mockMsRemaining')
    })
  })

})
