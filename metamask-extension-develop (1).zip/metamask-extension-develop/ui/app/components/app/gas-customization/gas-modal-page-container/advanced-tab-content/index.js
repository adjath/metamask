export { default } from './advanced-tab-content.component'
